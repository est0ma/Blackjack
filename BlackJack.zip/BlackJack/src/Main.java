public class Main implements Runnable {
	
	GUI virtuel = new GUI();
	

	public static void main(String[] args) {
		new Thread( new Main() ).start(); //launch a new main
	}

	@Override
	public void run() {
		while(true) { //when an button are hit he refresh
			virtuel.refresher();
			virtuel.repaint();
		}
	}

}