import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener; //this library its not in awt.* cause he import only library with 3 words

public class GUI extends JFrame { //jframe create the window so we just have to set size title ect 
	
	//screen resolution
	int aW = 720;
	int aH = 480;
	
	//game phase bool
	boolean bool_hit_stay = true;
	boolean bool_dealer_turn = false;
	
	//game question
	String play_more_q = "Play more?";
	
	//background color for board et buttons
	Color colorBackground = new Color(53,101,77);
	Color colorButton = new Color(128,128,128);
	
	
	//create boutons 
	JButton bHit = new JButton();
	JButton bStay = new JButton();
	JButton bYes = new JButton();
	JButton bNo = new JButton();
	
	//card emplacement
	int gridX = 200;
	int gridY = 70;
	int gridW = 350;
	int gridH = 150;
	
	//dimension card and placement
	int cardSpacing = 10;
	int cardTW = gridW/6;
	int cardTH = gridH/2;
	int cardAW = cardTW-2*cardSpacing;
	int cardAH = cardTH-2*cardSpacing;
	
	//arraylist card
	ArrayList<Card> allCards = new ArrayList<Card>(); //we use arraylist cause we dont have to declare dimensions
	ArrayList<Card> playerCards = new ArrayList<Card>();
	ArrayList<Card> dealerCards = new ArrayList<Card>();
	
	//total score
	int total_player;
	int total_dealer;
	
	//generate random number for cards
	int rand = new Random().nextInt(52);
	
	public GUI() {
		this.setSize(aW+6, aH+29); //to cover all the window
		this.setTitle("BlackJack");
		this.setVisible(true); //to launch the window when we start
		this.setResizable(false); //cant modificate the resolution of the window
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //turn off the program when we close the window
		
		Board board = new Board();
		this.setContentPane(board);
		this.setLayout(null); //if we dont do this setBounds didnt work
		
		//all button
		ActHit aHit = new ActHit();
		bHit.addActionListener(aHit);
		bHit.setBounds(35, 20, 80, 50); //dimention of button
		bHit.setBackground(colorButton);
		bHit.setText("HIT"); //use JButton to have possibility to put text on it 
		board.add(bHit);
		
		//put tree time for each buttons
		ActStay aStay = new ActStay();
		bStay.addActionListener(aStay);
		bStay.setBounds(35, 100, 80, 50);
		bStay.setBackground(colorButton);
		bStay.setText("STAY");
		board.add(bStay);
		
		ActYes aYes = new ActYes();
		bYes.addActionListener(aYes);
		bYes.setBounds(35, 250, 80, 50);
		bYes.setBackground(colorButton);
		bYes.setText("YES");
		board.add(bYes);
		
		ActNo aNo = new ActNo();
		bNo.addActionListener(aNo);
		bNo.setBounds(35, 330, 80, 50);
		bNo.setBackground(colorButton);
		bNo.setText("NO");
		board.add(bNo);
		
		String shapeS1 = null;
		int id_setter = 0;
		for (int s = 0; s < 4; s++) {
			if (s == 0) {
				shapeS1 = "Pique";
			} else if (s == 1) {
				shapeS1 = "Coeur";
			} else if (s == 2) {
				shapeS1 = "Carreau";
			} else if (s == 3) {
				shapeS1 = "Trefle";
			}
			for (int i = 2; i < 15; i++) { //loop for create all 52 cards
				allCards.add(new Card(i, shapeS1, id_setter));
				id_setter++;
			}
		}
		
		rand = new Random().nextInt(52);
		playerCards.add(allCards.get(rand)); //add to the player a card
		allCards.get(rand).cardUsed = true; //when we pick a card he goes to use
		
		rand = new Random().nextInt(52); //pick another card
		while(true) {
			if (allCards.get(rand).cardUsed == false) { //if card no use 
				dealerCards.add(allCards.get(rand)); //goes to dealer hand
				allCards.get(rand).cardUsed = true; //and goes to use
				break;
			} else {
				rand = new Random().nextInt(52); //if already use we pick another card
			}
		}
		
		rand = new Random().nextInt(52);
		while(true) {
			if (allCards.get(rand).cardUsed == false) {
				playerCards.add(allCards.get(rand)); 
				allCards.get(rand).cardUsed = true;
				break;
			} else {
				rand = new Random().nextInt(52);
			}
		}
		
		rand = new Random().nextInt(52);
		while(true) {
			if (allCards.get(rand).cardUsed == false) {
				dealerCards.add(allCards.get(rand)); 
				allCards.get(rand).cardUsed = true;
				break;
			} else {
				rand = new Random().nextInt(52);
			}
		}
		
		for (Card c : playerCards) {
			System.out.println("Player has the card " + c.name + " of " + c.shape);
		}
		for (Card c : dealerCards) {
			System.out.println("Dealer has the card " + c.name + " of " + c.shape);
		}
		
	}
	
	public void refresher() {
		
		//player total
		int sum = 0;
		for (Card c : playerCards) {
			sum += c.value;
		}
		total_player = sum;
		
		//dealer total
		sum = 0;
		for (Card c : dealerCards) {
			sum += c.value;
		}
		total_dealer = sum;

		
		//System.out.println("Player Totals: " + total_player );
		
	}
	
	//drawn graphic, score...
	public class Board extends JPanel { 
		
		public void paintComponent(Graphics g) {
			g.setColor(colorBackground);
			g.fillRect(150, 0, aW, aH); //for all the window
			
			//temporary grid painting
			g.setColor(Color.black);
			g.drawRect(gridX, gridY, gridW, gridH);
			//temporary log painting
			g.drawRect(gridX, gridY+gridH+70, gridW, 150);
				g.drawString(play_more_q, 45, 318);
				g.drawString(Integer.toString(total_player), 170, 115);
				g.drawString(Integer.toString(total_dealer), 170, 180);
			
			
			for (int i = 0; i < 6; i++) { //loop for place the cards
				g.drawRect(gridX+i*cardTW+cardSpacing, gridY+cardSpacing, cardAW, cardAH);
				g.drawRect(gridX+i*cardTW+cardSpacing, gridY+22+cardTW, cardAW, cardAH);
			}
			
			//card player
			int index = 0;
			for (Card c : playerCards) {
				g.setColor(Color.white);
				g.fillRect(gridX+index*cardTW+cardSpacing, gridY+cardSpacing, cardAW, cardAH);
				g.setColor(Color.black);
				g.drawString(c.symbol, gridX+index*cardTW+cardSpacing+2, gridY+cardAH+7);
				g.drawString(c.shape, gridX+index*cardTW+cardSpacing, gridY+cardAH-15);
				index++;
			}
			
			//card dealer
			if (bool_dealer_turn == true) {
				index = 0;
				for (Card c : dealerCards) {
					g.setColor(Color.white);
					g.fillRect(gridX+index*cardTW+cardSpacing, gridY+cardTH+cardSpacing-4, cardAW, cardAH);
					g.setColor(Color.black);
					g.drawString(c.symbol, gridX+index*cardTW+cardSpacing+2, gridY+cardTH+cardAH+3);
					g.drawString(c.shape, gridX+index*cardTW+cardSpacing, gridY+cardTH+cardAH-18);
					index++;
				}
			}
		}
	}
	
	public class ActHit implements ActionListener { //class for what appean when we clic the button

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("You just clicked the HIT button");
			rand = new Random().nextInt(52);
			while(true) {
				if (allCards.get(rand).cardUsed == false) {
					playerCards.add(allCards.get(rand)); 
					allCards.get(rand).cardUsed = true;
					break;
				} else {
					rand = new Random().nextInt(52);
				}
			}
		}
		
	}
	
	public class ActStay implements ActionListener { 

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("You just clicked the STAY button");
			bool_hit_stay = false;
			bool_dealer_turn = true;
			rand = new Random().nextInt(52);
			while(true) {
				if (allCards.get(rand).cardUsed == false) {
					dealerCards.add(allCards.get(rand)); 
					allCards.get(rand).cardUsed = true;
					break;
				} else {
					rand = new Random().nextInt(52);
				}
			}
			
		}
		
	}
	
	public class ActYes implements ActionListener { 

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("You just clicked the YES button");
		}
		
	}
	
	public class ActNo implements ActionListener { 

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("You just clicked the NO button");
		}
		
	}
	
}
